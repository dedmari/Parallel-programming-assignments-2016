#include "emsim.h"
#include <omp.h>

void playGroups(team_t* teams)
{
 // put your code here
}

void playFinalRound(int numGames, team_t** teams, team_t** successors)
{
 // put your code here
} 
