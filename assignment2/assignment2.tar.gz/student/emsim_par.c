#include "emsim.h"
#include <pthread.h>

void playGroups(team_t* teams, int numWorker)
{
 // put your code here
}

void playFinalRound(int numGames, team_t** teams, team_t** successors, int numWorker)
{
 // put your code here
} 
