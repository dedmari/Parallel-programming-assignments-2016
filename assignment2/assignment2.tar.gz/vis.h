#ifndef VIS_H
#define VIS_H

void handleGame(int index,
                const char* team1, const char* team2,
                int goals1, int goals2);
void visualize(int pos, int numMatches);
void visualizeEM();

#endif
