#include "ds.h"

char *names[31] = {
			"Julio",
			"Nicole", "Gabriel",
			"Michelle", "Emanuel" , "Cleora",  "Robbie",
			"Emily", "Sid", "Eugene", "Roger", "Suanne",  "Billie", "Twyla", "Werner",
			"Cersey", "Nickson", "Anna", "Edbert", "Charlote", "Jamie", "Mary", "John",
			"Elisabeth", "William", "Thomasina", "Cesar", "Evelynn", "Bill", "Alyssia", "Walt"
		  };

int g_node_id = 0;
