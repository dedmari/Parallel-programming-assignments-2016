#include "familytree.h"

void traverse(tree *node, int numThreads){
	
	// put your code in here	

}

